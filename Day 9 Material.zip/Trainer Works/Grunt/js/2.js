function fnTwo(){
    alert("This is SECOND function..., in the class")
}