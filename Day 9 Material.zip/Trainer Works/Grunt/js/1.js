function fnOne(){
    alert("Testing .... .")
}