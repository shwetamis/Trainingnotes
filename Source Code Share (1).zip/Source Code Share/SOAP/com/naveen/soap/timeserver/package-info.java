/**
 * 
 */
/**
 * @author Naveen Kumar K S
 *
 */
package com.naveen.soap.timeserver;

// the package is to implement SOAP time server and host 
