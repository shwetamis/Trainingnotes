function fnSecondFunction(){
    console.log("hello")
}