function fnFirst(){
    alert("You called first Function, hey clicked again")
}

function fnSecond(){
    console.log("This is second function");
}