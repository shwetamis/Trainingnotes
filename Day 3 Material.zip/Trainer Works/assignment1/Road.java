package com.fannie.assignment1;

public class Road {
	
	
	public void move(Vehicle v){
		v.move();
	}
	
	public void slowDown(Vehicle v){
		v.applyBreak();
	}
}
