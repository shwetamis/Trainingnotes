package com.fannie.inhe;

public class Vehicle {
	public void move(){
		System.out.println("All Vehicles Move");
	}
}
