package com.fannie.inhe;

public abstract  class FourWheeler extends Vehicle{
	public abstract void steering();
	
	
}
