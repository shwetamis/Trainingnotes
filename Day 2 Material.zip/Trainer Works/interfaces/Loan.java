package com.fannie.interfaces;

public interface Loan {
	void submitLoan();
	void loanAmount();
	void foreClosure();
	void foreClosure(int amount);
}
