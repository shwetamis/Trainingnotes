function fnHello(){
    console.log("Welcome from fnHello Section")
    // it is private 
    // var var1 ="hi";
    // var2 = "bye";

    var name = prompt("Enter Your Name :")
    var age = parseInt(prompt("Enter your age ", "20"))

    console.log("your name is " + name);
    if(age > 18){
        // console.log("you are good to have license");
        var mydiv = document.getElementById('mydiv');
        mydiv.innerHTML = "Hey you are good to go with license";
    }else{
       document.getElementById('mydiv').innerHTML= 
                "Sorry You got to wait for getting license"
    }
}
// write a program which will take a number and show the multiplication 
// table of it 
// 10 
// 10 x 1 = 10 
//...
// 10 x 10 = 100

function fnHi(){
    console.log("Welcome from fnHi Section")
   //  console.log("value of var1 " + var1);
    console.log("Value of var2 " + var2);
}