package com.fannie.collections;

import java.util.LinkedList;

public class ListEx5 {
	public static void main(String[] args) {
		LinkedList<String> list = new LinkedList<String>();
		// ?? 
	}
}
