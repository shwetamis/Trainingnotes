package com.fannie.collections;

import java.util.Set;
import java.util.TreeSet;

// working of treeset 

public class SetEx3 {
	public static void main(String[] args) {
		Set<String> set = new TreeSet<String>();
		
		set.add("Britt");
		set.add("Fusheng");
		set.add("Pundarika");
		set.add("Edmund");
		set.add("Kenrick");
		set.add("Raymond");
		
		System.out.println(set);
	
	}
}
