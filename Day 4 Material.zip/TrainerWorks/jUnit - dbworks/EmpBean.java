package com.fannie.dbworks;

public class EmpBean {
}